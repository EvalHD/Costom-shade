package com.customshade.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

data class SimpleNotif(
    val key: String,
    val appName: String,
    val title: String,
    val text: String
)

class ShadeNotificationListener : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: ShadeNotificationListener? = null
        val currentNotifications = CopyOnWriteArrayList<SimpleNotif>()

        fun refreshList() {
            val svc = instance ?: return
            try {
                val active = svc.activeNotifications ?: return
                val fresh = mutableListOf<SimpleNotif>()
                for (sbn in active) {
                    if (sbn.packageName == svc.packageName) continue
                    val extras = sbn.notification.extras
                    val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
                    val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
                    if (title.isBlank() && text.isBlank()) continue
                    val appName = try {
                        val pm = svc.packageManager
                        val info = pm.getApplicationInfo(sbn.packageName, 0)
                        pm.getApplicationLabel(info).toString()
                    } catch (_: Exception) {
                        sbn.packageName
                    }
                    fresh.add(SimpleNotif(sbn.key, appName, title, text))
                }
                currentNotifications.clear()
                currentNotifications.addAll(fresh)
            } catch (_: Exception) {
            }
        }

        fun clearAll() {
            try {
                instance?.cancelAllNotifications()
                currentNotifications.clear()
            } catch (_: Exception) {
            }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        refreshList()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        refreshList()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        refreshList()
    }
}
