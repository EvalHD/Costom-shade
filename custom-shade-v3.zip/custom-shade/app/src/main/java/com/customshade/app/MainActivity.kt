package com.customshade.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var btnToggleService: MaterialButton
    private lateinit var imgPreviewBg: ImageView
    private lateinit var tvDimLabel: TextView
    private lateinit var seekDim: SeekBar

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { saveBackgroundImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnToggleService = findViewById(R.id.btnToggleService)
        imgPreviewBg = findViewById(R.id.imgPreviewBg)
        tvDimLabel = findViewById(R.id.tvDimLabel)
        seekDim = findViewById(R.id.seekDim)

        btnToggleService.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Bitte zuerst Overlay-Berechtigung erlauben", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            if (Prefs.isServiceRunning(this)) {
                stopService(Intent(this, ShadeOverlayService::class.java))
                Prefs.setServiceRunning(this, false)
            } else {
                val i = Intent(this, ShadeOverlayService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(i)
                } else {
                    startService(i)
                }
                Prefs.setServiceRunning(this, true)
            }
            updateToggleButton()
        }

        findViewById<View>(R.id.btnPreviewShade).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            val i = Intent(this, ShadeOverlayService::class.java).apply {
                action = ShadeOverlayService.ACTION_OPEN_SHADE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(i)
            } else {
                startService(i)
            }
            Prefs.setServiceRunning(this, true)
            updateToggleButton()
        }

        findViewById<View>(R.id.btnPermOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<View>(R.id.btnPermNotif).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<View>(R.id.btnPermSettings).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }

        findViewById<View>(R.id.btnPickImage).setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        findViewById<View>(R.id.btnRemoveImage).setOnClickListener {
            val f = Prefs.getBgImageFile(this)
            if (f.exists()) f.delete()
            loadPreviewImage()
            notifyStyleChanged()
            Toast.makeText(this, "Hintergrundbild entfernt", Toast.LENGTH_SHORT).show()
        }

        val currentDim = Prefs.getDimPercent(this)
        seekDim.progress = currentDim
        tvDimLabel.text = "Hintergrund-Verdunkelung: $currentDim%"
        seekDim.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                tvDimLabel.text = "Hintergrund-Verdunkelung: $progress%"
                Prefs.setDimPercent(this@MainActivity, progress)
                notifyStyleChanged()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        setupColorRow(
            findViewById(R.id.rowAccentColors),
            listOf("#9B51E0", "#FF2E93", "#00E5FF", "#00E676", "#FFD600", "#FF5252", "#FFFFFF")
        ) { color ->
            Prefs.setAccentColor(this, color)
            notifyStyleChanged()
            Toast.makeText(this, "Akzentfarbe gespeichert", Toast.LENGTH_SHORT).show()
        }

        setupColorRow(
            findViewById(R.id.rowTileColors),
            listOf("#2E1F47", "#14141F", "#1B2A4A", "#3B1732", "#17332A", "#2E2418", "#000000")
        ) { color ->
            Prefs.setTileColor(this, color)
            notifyStyleChanged()
            Toast.makeText(this, "Kachelfarbe gespeichert", Toast.LENGTH_SHORT).show()
        }

        setupColorRow(
            findViewById(R.id.rowTextColors),
            listOf("#FFFFFF", "#E0B3FF", "#80F5FF", "#FFE57F", "#FF9EBB", "#B9F6CA")
        ) { color ->
            Prefs.setTextColor(this, color)
            notifyStyleChanged()
            Toast.makeText(this, "Textfarbe gespeichert", Toast.LENGTH_SHORT).show()
        }

        loadPreviewImage()
        updateToggleButton()
    }

    override fun onResume() {
        super.onResume()
        updateToggleButton()
    }

    private fun updateToggleButton() {
        btnToggleService.text = if (Prefs.isServiceRunning(this)) "Leiste stoppen" else "Leiste starten"
    }

    private fun saveBackgroundImage(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

            var sampleSize = 1
            val maxDim = 1440
            while (bounds.outWidth / sampleSize > maxDim * 2 || bounds.outHeight / sampleSize > maxDim * 2) {
                sampleSize *= 2
            }

            val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return

            val outFile = Prefs.getBgImageFile(this)
            FileOutputStream(outFile).use { out ->
                decoded.compress(Bitmap.CompressFormat.JPEG, 88, out)
            }
            decoded.recycle()

            loadPreviewImage()
            notifyStyleChanged()
            Toast.makeText(this, "Hintergrundbild gespeichert!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Fehler beim Laden des Bildes", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadPreviewImage() {
        val f = Prefs.getBgImageFile(this)
        if (f.exists()) {
            val bmp = BitmapFactory.decodeFile(f.absolutePath)
            imgPreviewBg.setImageBitmap(bmp)
        } else {
            imgPreviewBg.setImageDrawable(null)
        }
    }

    private fun notifyStyleChanged() {
        if (Prefs.isServiceRunning(this)) {
            val i = Intent(this, ShadeOverlayService::class.java).apply {
                action = ShadeOverlayService.ACTION_REFRESH_STYLE
            }
            startService(i)
        }
    }

    private fun setupColorRow(container: LinearLayout, hexColors: List<String>, onPick: (Int) -> Unit) {
        container.removeAllViews()
        val sizePx = (36 * resources.displayMetrics.density).toInt()
        val marginPx = (10 * resources.displayMetrics.density).toInt()
        for (hex in hexColors) {
            val colorInt = Color.parseColor(hex)
            val swatch = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply {
                    marginEnd = marginPx
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(colorInt)
                    setStroke((2 * resources.displayMetrics.density).toInt(), Color.parseColor("#88FFFFFF"))
                }
                setOnClickListener { onPick(colorInt) }
            }
            container.addView(swatch)
        }
    }
}
