package com.customshade.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ShadeOverlayService : Service() {

    companion object {
        const val ACTION_OPEN_SHADE = "com.customshade.app.OPEN_SHADE"
        const val ACTION_REFRESH_STYLE = "com.customshade.app.REFRESH_STYLE"
        private const val CHANNEL_ID = "custom_shade_channel"
    }

    private lateinit var windowManager: WindowManager
    private var triggerView: View? = null
    private var shadeView: View? = null
    private var isTorchOn = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, 101, createNotification(), fgsType)
        Prefs.setServiceRunning(this, true)
        addTopTriggerHandle()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_OPEN_SHADE -> openShadePanel()
            ACTION_REFRESH_STYLE -> {
                shadeView?.let { applyStyleToShade(it) }
                updateTriggerHandleColor()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Prefs.setServiceRunning(this, false)
        removeTriggerHandle()
        closeShadePanel()
    }

    private fun createNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                "CustomShade Aktiv",
                NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CustomShade ist aktiv")
            .setContentText("Tippe oder wische am Griff oben in der Mitte")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun getStatusBarHeight(): Int {
        val resId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId)
        else (28 * resources.displayMetrics.density).toInt()
    }

    /**
     * FIX for Android 12-15 & Samsung One UI:
     * SystemUI blocks TYPE_APPLICATION_OVERLAY touches inside the status bar itself.
     * Placing a sleek, centered pull-handle RIGHT BELOW the status bar guarantees
     * touches & downward swipes are NEVER stolen by Samsung's native shade.
     */
    private fun addTopTriggerHandle() {
        if (triggerView != null) return
        val density = resources.displayMetrics.density

        val container = FrameLayout(this)
        val pill = View(this).apply {
            tag = "pill"
            layoutParams = FrameLayout.LayoutParams(
                (76 * density).toInt(),
                (6 * density).toInt(),
                Gravity.CENTER_HORIZONTAL or Gravity.TOP
            ).apply {
                topMargin = (5 * density).toInt()
            }
        }
        container.addView(pill)

        var downY = 0f
        var opened = false
        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downY = event.rawY
                    opened = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!opened && event.rawY - downY > 24f) {
                        opened = true
                        openShadePanel()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!opened) {
                        // Also allow simple tap on the handle to open immediately!
                        openShadePanel()
                    }
                    true
                }
                else -> false
            }
        }

        val params = WindowManager.LayoutParams(
            (150 * density).toInt(),
            (26 * density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 0 // Because FLAG_LAYOUT_IN_SCREEN is NOT set, y=0 starts directly BELOW the status bar!
        }

        try {
            windowManager.addView(container, params)
            triggerView = container
            updateTriggerHandleColor()
        } catch (_: Exception) {
        }
    }

    private fun updateTriggerHandleColor() {
        val pill = triggerView?.findViewWithTag<View>("pill") ?: return
        val accent = Prefs.getAccentColor(this)
        val density = resources.displayMetrics.density
        pill.background = GradientDrawable().apply {
            setColor(Color.argb(215, Color.red(accent), Color.green(accent), Color.blue(accent)))
            cornerRadius = 6f * density
            setStroke((1 * density).toInt(), Color.argb(140, 255, 255, 255))
        }
    }

    private fun removeTriggerHandle() {
        triggerView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        triggerView = null
    }

    private fun openShadePanel() {
        if (shadeView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_shade, null)

        view.isFocusableInTouchMode = true
        view.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                closeShadePanel()
                true
            } else {
                false
            }
        }

        val now = Date()
        view.findViewById<TextView>(R.id.tvShadeClock).text =
            SimpleDateFormat("HH:mm", Locale.GERMAN).format(now)
        view.findViewById<TextView>(R.id.tvShadeDate).text =
            SimpleDateFormat("E, dd. MMM", Locale.GERMAN).format(now)

        view.findViewById<View>(R.id.btnShadeClose).setOnClickListener { closeShadePanel() }
        view.findViewById<View>(R.id.bottomHandle).setOnClickListener { closeShadePanel() }
        view.findViewById<View>(R.id.btnShadeAppSettings).setOnClickListener {
            closeShadePanel()
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        view.findViewById<View>(R.id.btnShadeSysSettings).setOnClickListener {
            openSystemSettings(Settings.ACTION_SETTINGS)
        }

        view.findViewById<View>(R.id.tileWifi).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                openSystemSettings(Settings.Panel.ACTION_WIFI)
            } else {
                openSystemSettings(Settings.ACTION_WIFI_SETTINGS)
            }
        }
        view.findViewById<View>(R.id.tileBluetooth).setOnClickListener {
            openSystemSettings(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
        view.findViewById<View>(R.id.tileTorch).setOnClickListener { toggleTorch() }
        view.findViewById<View>(R.id.tileSound).setOnClickListener { cycleRingerMode() }
        view.findViewById<View>(R.id.tileRotate).setOnClickListener { toggleAutoRotate() }
        view.findViewById<View>(R.id.tileDnd).setOnClickListener { toggleDnd() }
        view.findViewById<View>(R.id.tileAirplane).setOnClickListener {
            openSystemSettings(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
        }
        view.findViewById<View>(R.id.tileLocation).setOnClickListener {
            openSystemSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        }
        view.findViewById<View>(R.id.tileBattery).setOnClickListener {
            openSystemSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        }
        view.findViewById<View>(R.id.tileMobileData).setOnClickListener {
            openSystemSettings(Settings.ACTION_DATA_ROAMING_SETTINGS)
        }

        val seekBrightness = view.findViewById<SeekBar>(R.id.seekBrightness)
        try {
            val curBright = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            seekBrightness.progress = curBright
        } catch (_: Exception) {
        }
        seekBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && Settings.System.canWrite(this@ShadeOverlayService)) {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, progress)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val seekVolume = view.findViewById<SeekBar>(R.id.seekVolume)
        seekVolume.max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        seekVolume.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        view.findViewById<View>(R.id.btnClearNotifs).setOnClickListener {
            ShadeNotificationListener.clearAll()
            populateNotifications(view)
        }
        populateNotifications(view)

        applyStyleToShade(view)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        try {
            windowManager.addView(view, params)
            view.requestFocus()
            shadeView = view
        } catch (_: Exception) {
        }
    }

    private fun closeShadePanel() {
        shadeView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        shadeView = null
    }

    private fun applyStyleToShade(view: View) {
        val accent = Prefs.getAccentColor(this)
        val tileBase = Prefs.getTileColor(this)
        val textCol = Prefs.getTextColor(this)
        val dimPercent = Prefs.getDimPercent(this)

        val bgFile = Prefs.getBgImageFile(this)
        val bgImg = view.findViewById<ImageView>(R.id.shadeBgImage)
        val root = view.findViewById<View>(R.id.shadeRoot)
        val dimView = view.findViewById<View>(R.id.shadeDimView)

        if (bgFile.exists()) {
            val bmp = BitmapFactory.decodeFile(bgFile.absolutePath)
            if (bmp != null) {
                bgImg.setImageBitmap(bmp)
                bgImg.visibility = View.VISIBLE
            }
        } else {
            bgImg.visibility = View.GONE
            root.setBackgroundColor(tileBase)
        }

        val dimAlpha = (dimPercent * 255 / 100).coerceIn(0, 230)
        dimView.setBackgroundColor(Color.argb(dimAlpha, 0, 0, 0))

        val tileColorWithAlpha = Color.argb(175, Color.red(tileBase), Color.green(tileBase), Color.blue(tileBase))
        val tileIds = listOf(R.id.tileWifi, R.id.tileBluetooth, R.id.cardQuickGrid, R.id.cardSliders)
        for (id in tileIds) {
            val bg = GradientDrawable().apply {
                setColor(tileColorWithAlpha)
                cornerRadius = 22f * resources.displayMetrics.density
            }
            view.findViewById<View>(id)?.background = bg
        }

        val accentList = ColorStateList.valueOf(accent)
        view.findViewById<SeekBar>(R.id.seekBrightness)?.apply {
            progressTintList = accentList
            thumbTintList = accentList
        }
        view.findViewById<SeekBar>(R.id.seekVolume)?.apply {
            progressTintList = accentList
            thumbTintList = accentList
        }

        val textIds = listOf(
            R.id.tvShadeClock, R.id.tvShadeDate, R.id.btnShadeClose,
            R.id.tvWifiLabel, R.id.tvBtLabel,
            R.id.tileTorch, R.id.tileSound, R.id.tileRotate, R.id.tileDnd,
            R.id.tileAirplane, R.id.tileLocation, R.id.tileBattery, R.id.tileMobileData,
            R.id.tvNotifHeader, R.id.btnClearNotifs
        )
        for (id in textIds) {
            view.findViewById<TextView>(id)?.setTextColor(textCol)
        }
    }

    private fun populateNotifications(view: View) {
        val container = view.findViewById<LinearLayout>(R.id.notifContainer)
        container.removeAllViews()
        ShadeNotificationListener.refreshList()
        val list = ShadeNotificationListener.currentNotifications.toList()
        val textCol = Prefs.getTextColor(this)
        val tileBase = Prefs.getTileColor(this)
        val cardColor = Color.argb(185, Color.red(tileBase), Color.green(tileBase), Color.blue(tileBase))

        if (list.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "Keine Benachrichtigungen"
                setTextColor(textCol)
                alpha = 0.7f
                setPadding(16, 20, 16, 20)
            }
            container.addView(emptyTv)
            return
        }

        for (item in list.take(8)) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(36, 28, 36, 28)
                background = GradientDrawable().apply {
                    setColor(cardColor)
                    cornerRadius = 18f * resources.displayMetrics.density
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 16 }
            }
            val tvTitle = TextView(this).apply {
                text = "${item.appName} • ${item.title}"
                setTextColor(textCol)
                textSize = 14f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            val tvBody = TextView(this).apply {
                text = item.text
                setTextColor(textCol)
                alpha = 0.85f
                textSize = 13f
            }
            card.addView(tvTitle)
            if (item.text.isNotBlank()) card.addView(tvBody)
            container.addView(card)
        }
    }

    private fun openSystemSettings(action: String) {
        closeShadePanel()
        try {
            val i = Intent(action)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
        }
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cm.cameraIdList.firstOrNull() ?: return
            isTorchOn = !isTorchOn
            cm.setTorchMode(cameraId, isTorchOn)
        } catch (_: Exception) {
            Toast.makeText(this, "Taschenlampe nicht verfügbar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cycleRingerMode() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val next = when (audio.ringerMode) {
            AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
            AudioManager.RINGER_MODE_VIBRATE -> AudioManager.RINGER_MODE_SILENT
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        try {
            audio.ringerMode = next
            val label = when (next) {
                AudioManager.RINGER_MODE_NORMAL -> "Ton: Normal"
                AudioManager.RINGER_MODE_VIBRATE -> "Ton: Vibration"
                else -> "Ton: Stumm"
            }
            Toast.makeText(this, label, Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            openSystemSettings(Settings.ACTION_SOUND_SETTINGS)
        }
    }

    private fun toggleDnd() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            openSystemSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return
        }
        val next = if (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL) {
            NotificationManager.INTERRUPTION_FILTER_NONE
        } else {
            NotificationManager.INTERRUPTION_FILTER_ALL
        }
        nm.setInterruptionFilter(next)
        val label = if (next == NotificationManager.INTERRUPTION_FILTER_NONE) "Ruhemodus: An" else "Ruhemodus: Aus"
        Toast.makeText(this, label, Toast.LENGTH_SHORT).show()
    }

    private fun toggleAutoRotate() {
        if (!Settings.System.canWrite(this)) {
            openSystemSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS)
            return
        }
        val cur = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
        val next = if (cur == 1) 0 else 1
        Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, next)
        Toast.makeText(this, if (next == 1) "Drehen: An" else "Drehen: Aus", Toast.LENGTH_SHORT).show()
    }
}
