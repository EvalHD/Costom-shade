package com.customshade.app

import android.content.Context
import android.graphics.Color
import java.io.File

object Prefs {
    private const val PREF_NAME = "custom_shade_prefs"
    private const val KEY_ACCENT = "accent_color"
    private const val KEY_TILE = "tile_color"
    private const val KEY_TEXT = "text_color"
    private const val KEY_DIM = "dim_percent"
    private const val KEY_RUNNING = "service_running"

    fun getAccentColor(ctx: Context): Int =
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_ACCENT, Color.parseColor("#9B51E0"))

    fun setAccentColor(ctx: Context, color: Int) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putInt(KEY_ACCENT, color).apply()
    }

    fun getTileColor(ctx: Context): Int =
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_TILE, Color.parseColor("#2E1F47"))

    fun setTileColor(ctx: Context, color: Int) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putInt(KEY_TILE, color).apply()
    }

    fun getTextColor(ctx: Context): Int =
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_TEXT, Color.WHITE)

    fun setTextColor(ctx: Context, color: Int) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putInt(KEY_TEXT, color).apply()
    }

    fun getDimPercent(ctx: Context): Int =
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_DIM, 45)

    fun setDimPercent(ctx: Context, percent: Int) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putInt(KEY_DIM, percent).apply()
    }

    fun isServiceRunning(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_RUNNING, false)

    fun setServiceRunning(ctx: Context, running: Boolean) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_RUNNING, running).apply()
    }

    fun getBgImageFile(ctx: Context): File = File(ctx.filesDir, "shade_bg.jpg")
}
