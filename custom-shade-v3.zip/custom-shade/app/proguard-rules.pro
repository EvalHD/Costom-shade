# Standard ProGuard rules
